import argparse
import numpy as np
import torch
from pathlib import Path
from datetime import datetime
import multiprocessing
from ultralytics import YOLO
from tool import get_fpath, get_rootpath, get_ymval, get_FPS, str2bool


def main(trainornot, path, jsonfile, model, data, amp, batch, epoch, workers):
    # path = "C:/Users/ZJW18/Desktop/MODEL/runs/test_coco8/2024-07-01_16-45-33/weights/last.pt"
    time_str = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
    multiprocessing.freeze_support()
    model_name = f"{model.split('.')[0]}{get_ymval(model, 'num')}_{data.split('.')[0]}"
    save = model_name.split('_')
    # 获取项目文件路径
    ROOT = Path(get_rootpath()).parents[0]
    # 将模型的各项指标参数保存到csv文件
    target_path = str(ROOT / "runs/results.csv")
    # 获取数据集路径
    data = get_fpath(data)
    if trainornot == True:
        # Load a model
        Model = YOLO(f"{model}")  # build a new model from scratch
        # Model = YOLO("yolov8n.pt")
        # 用训练时间命名保存路径
        Model.train(data=f'{data}', batch=batch, epochs=epoch, workers=workers, amp=amp,
                    # optimizer='SGD', lr0=0.01,
                    project=f'../runs/{model_name}', name=f'{time_str}', )  # train the model

        source_path = str(ROOT / f"runs/{model_name}/{time_str}")
    elif trainornot == False:
        # Load a model
        Model = YOLO(path)
        # Resume training
        Model.train(resume=True)
        # 用第一次开始训练时间命名保存路径
        source_path = str(Path(path).parents[1])
        time_str = path.split('/')[-3]

    if jsonfile is not None:
        json_path = get_fpath(jsonfile, Path(get_rootpath()).parents[0])
    else:
        json_path = None
    part = 'val'  # 用的数据集的哪个部分val/test
    result = Model.val(split=part, save_json=True, project=f'../runs/{model_name}/{time_str}',
                       name=part, json_path=json_path)
    save[1] = save[1]+'-'+part+'-'+str(batch)
    states = Model.get_outarg()
    if states is not None:
        states = [f"{num:.5f}" for num in states]
    else:
        print('没有获取COCO指标！！！')
    n_l, n_p, n_g, gflops = Model.info()
    weights = source_path + '/weights/best.pt'
    FPS, size = get_FPS(weights)

    save.extend([
        f'{result.box.map50:.5f}', f'{result.box.map75:.5f}', f'{result.box.map:.5f}',
        f'{np.mean(result.box.p):.5f}', f'{np.mean(result.box.r):.5f}', f'{n_p}',
        f'{gflops:.5f}', f'{FPS}', f'{n_l}', f'{size}', f'{epoch}', f'{time_str}'])
    if states is not None:
        save.extend([*states[:6], *states[-4:]])
    save_str = []
    for i, dt in enumerate(save):
        if i == 0:
            save_str.append('{:<25}'.format(dt))
        elif i == 1:
            save_str.append('{:<16}'.format(dt))
        elif i == 13:
            save_str.append('{:>21}'.format(dt))
        else:
            save_str.append('{:>10}'.format(dt))
    save_str = ','.join(save_str)
    # 将数据存入指定csv文件
    with open(target_path, mode='a', newline='', encoding='utf-8') as tf:
        tf.write(save_str + '\n')

    print(f'模型{model_name}训练完成！')


if __name__ == '__main__':
    # 解析传入的参数
    # jsonfile = 'instances_voc2012val.json'
    # jsonfile = 'instances_val2017.json'
    # jsonfile = 'instances_voctest2007.json'
    # jsonfile = 'instances_CCVal.json'
    parser = argparse.ArgumentParser()
    parser.add_argument('--trainornot', type=str2bool, default=True, help='直接训练还是续接训练')
    parser.add_argument('--path', type=str, default=None, help='续接训练的last.pt文件路径')
    parser.add_argument('--jsonfile', type=str, default=None, help='COCO验证文件，没有则不会输出COCO指标')
    parser.add_argument('--model', type=str, default='GFP-YOLO.yaml', help='模型yaml文件')
    parser.add_argument('--data', type=str, default='coco8.yaml', help='数据集yaml文件')
    parser.add_argument('--amp', type=str2bool, default=True, help='是否使用混合精度训练')
    parser.add_argument('--batch', type=int, default=8, help='batchsize')
    parser.add_argument('--epoch', type=int, default=2, help='训练轮数')
    parser.add_argument('--workers', type=int, default=2, help='使用线程数')

    args = parser.parse_args()
    # "main"这种方式可以实现多进程
    main(trainornot=args.trainornot, path=args.path, jsonfile=args.jsonfile, model=args.model,
         data=args.data, amp=args.amp, batch=args.batch, epoch=args.epoch, workers=args.workers)

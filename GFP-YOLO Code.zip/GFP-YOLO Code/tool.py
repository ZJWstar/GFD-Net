import argparse
import warnings
import time
import os
import numpy as np
import torch
import yaml
from tqdm import tqdm

from ultralytics import YOLO
from ultralytics.utils.torch_utils import select_device
from ultralytics.nn.tasks import attempt_load_weights



def append_line(source_path, target_path, md_pm):

    """
    将一个CSV文件的最后一行添加到另一个CSV文件的最后一行,并将源文件的第八列最大值所在行加入目标文件最后一行。
    即将结果文件中的最后一轮和mp最高的一轮结果加入到目标文件。
    参数:
    source_path (str): 源CSV文件的路径。
    target_path (str): 目标CSV文件的路径。
    md_pm (list): 包含模型参数和性能指标的列表。
    """
    mm_str = ','.join(md_pm)
    with open(source_path+'/results.csv', mode='r', newline='', encoding='utf-8') as source_file:
        lines = source_file.readlines()  # 读取所有行
        last_line = lines[-1].strip()  # 获取最后一行并去除换行符
        max_value_row = None
        max_value = None
        for line in lines:
            row = line.strip().split(',')  # 拆分列
            if row:  # 确保行不为空
                try:
                    current_value = float(row[7])  # 假设第八列的值是可以转换为浮点数的
                    if max_value is None or current_value > max_value:
                        max_value = current_value
                        max_value_row = row
                except ValueError:
                    # 忽略无法转换为浮点数的行
                    pass

    # 如果找到了最大值所在行，将其追加到目标CSV文件
    with open(target_path, mode='a', newline='', encoding='utf-8') as target_file:
        last_line = str(last_line + ',' + mm_str)
        # last_line.append('time')  # Add the string 'abc' as a new column
        # last_line = ','.join(last_line)  # 重新组合列
        if max_value_row:
            max_value_row = ','.join(max_value_row) + ',' + mm_str
            target_file.write(max_value_row + '\n')
        target_file.write(last_line + '\n')  # 将最后一行写入目标文件


def get_rootpath():
    """
    获取项目根目录。此函数的能力体现在，不论当前module被import到任何位置，都可以正确获取项目根目录
    """
    path = os.path.realpath(os.curdir)
    while True:
        # PyCharm项目中，'.idea'是必然存在的，且名称唯一
        if '.idea' in os.listdir(path):
            return path
        path = os.path.dirname(path)
        if path == '/':
            return None


def get_fpath(fname, dir=None):
    """
    获取文件的路径
    Args:
        fname: 文件名
    Returns: 返回路径(包含文件名)
    """
    file_path = None
    if dir is not None:
        filedir = dir
    else:
        filedir = get_rootpath()
    # 遍历文件夹及子文件夹，并查找目标文件
    for root, dirs, files in os.walk(filedir):
        if fname in files:
            file_path = os.path.join(root, fname)
    if file_path is None:
        warnings.warn(f"未找到文件{fname}")
        pass
    return file_path

def get_ymval(fname, key):
    """
    获取yaml文件对应键的值
    Args:
        fname: yaml文件名
        key: 要获取值对应的键
    Returns: 返回对应键的值
    """
    if fname.split('.')[-1] != 'yaml':
        warnings.warn(f"文件{fname}不是yaml文件")
        return ''
    file_path = get_fpath(fname)
    # 打开 YAML 文件
    if file_path is not None:
        with open(f'{file_path}', 'r', encoding='utf-8') as file:
            # 加载YAML数据
            data = yaml.safe_load(file)
            # 读取YAML 文件中的值
            value = data.get(key)
    else:
        return ''
    if value is None:
        return ''
    return value


warnings.filterwarnings('ignore')

def get_weight_size(path):
    stats = os.stat(path)
    return f'{stats.st_size / 1024 / 1024:.1f}'


def get_FPS(MDweight):
    opt = {
        'weights': f'{MDweight}',
        'batch': 1,
        'imgs': [640, 640],
        'device': '',
        'warmup': 200,
        'testtime': 1000,
        'half': False
    }

    device = select_device(opt['device'], batch=opt['batch'])

    # Model
    weights = opt['weights']
    if weights.endswith('.pt'):
        model = attempt_load_weights(weights, device=device, fuse=True)
        print(f'Loaded {weights}')  # report
    else:
        model = YOLO(weights).model
        model.fuse()

    model = model.to(device)
    example_inputs = torch.randn((opt['batch'], 3, *opt['imgs'])).to(device)

    if opt['half']:
        model = model.half()
        example_inputs = example_inputs.half()

    print('begin warmup...')
    for i in tqdm(range(opt['warmup']), desc='warmup....'):
        model(example_inputs)

    print('begin test latency...')
    time_arr = []

    for i in tqdm(range(opt['testtime']), desc='test latency....'):
        if device.type == 'cuda':
            torch.cuda.synchronize()
        start_time = time.time()

        model(example_inputs)

        if device.type == 'cuda':
            torch.cuda.synchronize()
        end_time = time.time()
        time_arr.append(end_time - start_time)

    std_time = np.std(time_arr)
    infer_time_per_image = np.sum(time_arr) / (opt['testtime'] * opt['batch'])

    if opt['weights'].endswith('.pt'):
        print(
            f'model weights:{opt["weights"]} size:{get_weight_size(opt["weights"])}M (bs:{opt["batch"]})Latency:{infer_time_per_image:.5f}s +- {std_time:.5f}s fps:{1 / infer_time_per_image:.1f}')
    else:
        print(
            f'model yaml:{opt["weights"]} (bs:{opt["batch"]})Latency:{infer_time_per_image:.5f}s +- {std_time:.5f}s fps:{1 / infer_time_per_image:.1f}')

    return f'{1 / infer_time_per_image:.1f}', f'{get_weight_size(opt["weights"])}M'

def str2bool(v):
    if isinstance(v, bool):
        return v
    if v.lower() in ('yes', 'true', 't', 'y', '1'):
        return True
    elif v.lower() in ('no', 'false', 'f', 'n', '0'):
        return False
    else:
        raise argparse.ArgumentTypeError('Boolean value expected.')
import subprocess
import time


def read_and_remove_first_line(file_path):
    with open(file_path, 'r') as file:
        lines = file.readlines()

    if not lines:
        return None

    first_line = lines[0].strip()

    with open(file_path, 'w') as file:
        file.writelines(lines[1:])

    return first_line


file_path = 'parameters.txt'
# 格式：
# --trainornot True --model GFP-YOLO.yaml --data coco8.yaml --amp True --batch 8 --epoch 3 --workers 2
# --trainornot True --model GFP-YOLO.yaml --data VOC.yaml --jsonfile instances_voctest2007.json --amp True --batch 32 --epoch 200 --workers 8

while True:
    param_line = read_and_remove_first_line(file_path)
    if param_line is None:
        break

    param_group = param_line.split()
    subprocess.run(['python', 'MyTrain.py', *param_group])
    time.sleep(10)


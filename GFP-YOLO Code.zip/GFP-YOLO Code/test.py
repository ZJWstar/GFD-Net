import torch

# 加载模型
model_dict = torch.load('yolo11n.pt')

# 获取训练配置
training_args = model_dict['model'].args

# 获取 epochs 值
epochs = training_args.get('epochs')

print(f"训练时的 epochs 数为: {epochs}")